/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topic10;

/**
 *
 * @author n.a.chugaev
 */
public class Measure {
    double value = 0;
    public double convertToInch(){
        return value * 0.393701;
    }
    public double convertToFoot(){
        return value * 0.0328084;
    }
    public double convertToMetr(){
        return value * 0.01;
    }
    public double convertToMicroMetr(){
        return value * 10000;
    }
    
    
}

