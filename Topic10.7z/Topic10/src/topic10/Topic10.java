/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package topic10;
import topic10.Measure;

/**
 *
 * @author n.a.chugaev
 */
public class Topic10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Measure measure = new Measure();
        measure.value = 100;
        
        System.out.println(measure.convertToFoot());
        System.out.println(measure.convertToMetr());
        System.out.println(measure.convertToInch());
        System.out.println(measure.convertToMicroMetr());
        
    }
    
}
